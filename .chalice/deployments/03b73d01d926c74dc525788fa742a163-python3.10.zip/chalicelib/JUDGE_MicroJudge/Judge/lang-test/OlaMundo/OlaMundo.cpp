#include <stdio.h>

int main(void)
{
  printf("Ola Mundo\n");
  return 0;
}
