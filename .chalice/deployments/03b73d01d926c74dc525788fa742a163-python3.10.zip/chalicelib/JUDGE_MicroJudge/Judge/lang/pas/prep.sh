#!/bin/bash

cp /etc/fpc.cfg $1/
